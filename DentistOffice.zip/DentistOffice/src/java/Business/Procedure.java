/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.sql.*;
/**
 * @author Bharti Parekh
 */
public class Procedure {
    private  String procCode; 
    private  String procName; 
    private  String procDesc; 
    private double cost; 
    private String url = "C:/Users//coned//Downloads/DentistOfficeMDB.mdb";
    // Constructor with no argument 
    public Procedure(){ 
        procCode= ""; 
        procName = ""; 
        procDesc = ""; 
        cost = 0.0; 
    } 

    public Procedure (String  pcode, String pname, String pdes, double cs ) { 
        procCode= pcode; 
        procName = pname; 
        procDesc = pdes; 
        cost = cs; 
    } 

    public void selectDB(String pcode){ 
        procCode= pcode; 
        try{// Establish a connection 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url)) { 
                System.out.println("Database connected"); 
                // Create a statement 
                Statement smt = con.createStatement(); 
                // Execute a statement 
                String sql = "SELECT * FROM Procedures WHERE procCode = '"+ pcode +"'" ; 
                System.out.println(sql); 
                ResultSet rs = smt.executeQuery (sql); 
                rs.next(); 
                procCode = rs.getString(1); 
                procName = rs.getString(2); 
                procDesc = rs.getString(3); 
                cost = rs.getDouble(4); 
                } 
        }//end try//end try 
        catch(ClassNotFoundException | SQLException e){ 
            System.out.println(e); 
        } 
    }//End selectDB()     

    public String getProcCode() { return procCode; } 
    public void setProcCode(String pCode) {procCode= pCode ; } 

    public String getProcName() { return procName; } 
    public void setProcName (String pname) {procName = pname ; } 

    public String getProcDesc() { return procDesc; } 
    public void setProcDesc (String pdes) {procDesc = pdes ; } 

    public double getCost() { return cost; } 
    public void setCost (double cs) {cost = cs ; } 

    public void display(){ 
        System.out.println("ProcCode     = "+ procCode); 
        System.out.println("ProcName     = "+ procName); 
        System.out.println("ProcDesc     = "+ procDesc); 
        System.out.println("Cost         = "+cost); 
        System.out.println("-----------------------------");
    }//End display()

    public void insertDB(String  pcode, String pname, String pdes, double cs ) { 
        procCode = pcode; 
        procName = pname; 
        procDesc = pdes; 
        cost = cs; 
        // Establish a connection 
        try { 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                +url); 
            System.out.println("Database connected"); 
            // Create a statement 
            Statement smt; 
            smt = con.createStatement(); 
            // Execute a statement 
            String sql = "Insert into Procedures values('" +procCode+ "', '" +procName+  "', '" +procDesc+  "' , '" +cost+ "')";  
            System.out.println(sql); 
            int n = smt.executeUpdate (sql); 
            if (n == 1) 
                System.out.println("Insert Successful"); 
            else 
                System.out.println("Insert Failed"); 
            }//end  
        catch(ClassNotFoundException | SQLException e){ 
            System.out.println(e); 
        } 
    }// End insertDB 

    public void deleteDB() { 
        try{ 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                +url) ; 
            System.out.println("Database connected"); 
            // Create a statement 
            Statement smt = con.createStatement(); 
            // Execute a statement 
            String sql = "Delete * FROM Procedures WHERE procCode ='"+ procCode+"'"; 
            System.out.println(sql); 
            int n = smt.executeUpdate (sql); 
            if (n == 1) {
                System.out.println("Appointment delete Successfully"); 
                System.out.println("-----------------------------");
            }
            else 
                System.out.println("Delete Failed"); 
        }//end try//end try 
        catch(SQLException e){ 
            System.out.println(e); 
        }      
    } //End deleteDB 

    public void updateDB() { 
        try { 
            try ( //  Establish a connection 
                Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url)) {
                System.out.println("Database connected");
                // Create a statement
                Statement smt = con.createStatement();
                // Updating database
                String sql = "UPDATE  Procedures set procName ='"+getProcName()+"', procDesc ='"+ getProcDesc()+"', cost ="+ getCost()+" WHERE procCode ='"+getProcCode()+"'";
                System.out.println(sql);
                int x = smt.executeUpdate(sql);
                if (x > 0) {
                    System.out.println("Successfully Updated");
                    System.out.println("-----------------------------");
                }
                else {
                    System.out.println("ERROR OCCURED :(");
                }
            }
        }//end try //end try 
        catch(SQLException e){ 
            System.out.println(e); 
        }      
    }//End updateDB()

    public  static void main(String[] args){ 
        //SELECT Procedure
        Procedure p1; 
        p1 = new Procedure (); 
        p1.selectDB("P119"); 
        p1.display(); 

        //INSERT Procedure
        Procedure p2 = new Procedure (); 
        p2.insertDB("P830", "Apexication ", "Root resporption", 550.50); 
        p2.display(); 
        
        //UPDATE Procedure
        //Procedure p3 = new Procedure();
        //p3.selectDB("P800");
        //p3.setCost(950.89);
        //p3.updateDB();
        
        //DELETE Procedure
        //Procedure p4 = new Procedure (); 
        //p4.selectDB("P800"); 
        //p4.deleteDB();
    }//End main
}//End class