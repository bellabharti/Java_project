/*
 * Document   : UpdateAppointmentServlet
 * Author     : Bharti Parekh
 */
import Business.Patient;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(name = "UpdateAppointmentServlet", urlPatterns = {"/UpdateAppointmentServlet"})
public class UpdateAppointmentServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            RequestDispatcher rd;
        
            //Get values from textbox
            String dateTime = request.getParameter("aptb");
            String patId = request.getParameter("pidtb");
            String dentId = request.getParameter("didtb");
            String proCode =  request.getParameter("pcodetb");
            
            //Get Patient Object out of Session
            //Set Appointment Values
            //Update Appointment
            HttpSession session = request.getSession();
            Patient p1 = (Patient)session.getAttribute("p1");
            p1.appt.myList.get(0).setApptDateTime(dateTime);
            p1.appt.myList.get(0).setDentID(dentId);
            p1.appt.myList.get(0).setProcCode(proCode);
            p1.appt.myList.get(0).updateDB();
            
            //Forward to PDisplayAppointment.jsp
            rd = request.getRequestDispatcher("/PDisplayAppointment.jsp");
            rd.forward(request,response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
