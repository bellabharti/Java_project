/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.sql.*;
/**
 * @author Bharti Parekh
 */
public class Patient {
    private String patId;
    private String passwd;
    private String firstName;
    private String lastName;
    private String addr;
    private String email;
    private String insCo;
    private String url = "C:/Users//coned//Downloads/DentistOfficeMDB.mdb";
    public AppointmentList appt = new AppointmentList();
    /**
     * This constructor should be called with inputs which already exist in the
     * Appointments table.
     **/
    
    // Constructor with no argument
    public Patient(){
        patId = "";
        passwd = "";
        firstName = "";
        lastName = "";
        addr = "";
        email = "";
        insCo = "";
    }

    public Patient(String pid,String pw, String fname, String lname, String add, String eml, String inc) {
        patId = pid;
        passwd = pw;
        firstName = fname;
        lastName =  lname;
        addr = add;
        email = eml;
        insCo = inc;
    }
    
    public void selectDB(String pid){
        patId= pid;
        try{
             // Establish a connection
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url)) {
                System.out.println("Database connected");
                // Create a statement
                Statement smt = con.createStatement();
                // Execute a statement
                String sql = "SELECT * FROM Patients WHERE patId = '"+getPatId() +"'" ;
                System.out.println(sql);
                ResultSet rs = smt.executeQuery (sql);
                rs.next();
                patId = rs.getString("patId");
                passwd = rs.getString("passwd");
                firstName =  rs.getString("firstName");
                lastName =   rs.getString("lastName");
                addr = rs.getString("addr");
                email =  rs.getString("email");
                insCo = rs.getString("insCo");
                getAppointments();
            }
        }//end try//end try
        catch(ClassNotFoundException | SQLException e){
            System.out.println(e);
        }
    }//end selectDB()
    
    public void getAppointments() { 
        try{// Establish a connection 
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                +url)) { 
                System.out.println("Finding Appointments"); 
                // Create a statement 
                Statement smt = con.createStatement(); 
                // Execute a statement 
                String sql = "SELECT patId FROM Appointments WHERE patId ='"+patId+"'"; 
                //System.out.println(sql); 
                ResultSet rs = smt.executeQuery (sql);
                while(rs.next()){ 
                    Appointment a1 = new Appointment();
                    String pid = rs.getNString("patId");
                    a1.selectDB(pid);
                    appt.addAppointment(a1);
                } 
            } 
        }//end try//end try 
        catch(ClassNotFoundException | SQLException e){ 
            System.out.println(e); 
        } 
    }//End getAppointments() 
    
    public String getPatId() { return patId; }
    public void setPatId(String pid) { patId= pid ; }

    public String getPassword() { return passwd; }
    public void setPassword(String  pass) {passwd= pass ; }

    public String getFName() { return firstName; }
    public void setFName(String fn) {firstName= fn ; }

    public String getLName() { return lastName; }
    public void setLName(String ln) {lastName= ln ; }

    public String getAddress() { return addr; }
    public void setAddress(String adr) {addr= adr ; }

    public String getEmail() { return email; }
    public void setEmail(String eml) {email= eml ; }

    public String getInsCo() { return insCo; }
    public void setInsCo(String inco) {insCo= inco ; }

    public void display(){
        System.out.println("Patient ID      = "+ patId);
        System.out.println("Password        = "+ passwd);
        System.out.println("First Name      = "+ firstName);
        System.out.println("Last Name       = "+ lastName);
        System.out.println("Address         = "+ addr);
        System.out.println("Email           = "+ email);
        System.out.println("InsCo           = "+ insCo);
        System.out.println("***************** My Appointment");
        appt.display();
        System.out.println("*****************");
        System.out.println("-----------------------------");
    }
    
    public void insertDB(String pid,String pw, String fname, String lname, String add, String eml, String inc) {
        patId = pid;
        passwd = pw;
        firstName = fname;
        lastName =  lname;
        addr = add;
        email = eml;
        insCo = inc;
        // Establish a connection
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url);
            System.out.println("Database connected");
            // Create a statement
            Statement smt;
            smt = con.createStatement();
            // Execute a statement
            String sql = "Insert into Patients(patid, passwd, firstName, lastName,addr, email, insCo) values( '" +patId+  "', '" +passwd+  "' , '" +firstName+ "', '" +lastName+  "' , '" +addr+  "' , '" +email+  "' , '" +insCo+  "' )"; 
            System.out.println(sql);
            int n = smt.executeUpdate (sql);
            if (n == 1)
               System.out.println("Insert Successful");
               else
               System.out.println("Insert Failed");
        }//end 
        catch(ClassNotFoundException | SQLException e){
            System.out.println(e);
        }
    }// End insertDB
 
   public void deleteDB() {
        try{
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url) ;
                System.out.println("Database connected");
                // Create a statement
                Statement smt = con.createStatement();
                // Execute a statement
                String sql = "Delete * FROM Patients WHERE patId ='"+patId+"'";
                System.out.println(sql);
                int n = smt.executeUpdate (sql);
                if (n == 1)
                    System.out.println("Patient delete Successfully");
                else
                    System.out.println("Delete Failed");
        }//end try//end try
        catch(SQLException e){
            System.out.println(e);
        }     
    } //End deleteDB

   public void updateDB() {
        try {
            try ( //  Establish a connection
                Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                        +url)) {
                System.out.println("Database connected");
                // Create a statement
                Statement smt = con.createStatement();
                // Updating database
                String sql = "UPDATE Patients set passwd ='"+getPassword()+"', firstName ='"+getFName()+"', lastName ='"+getLName()+"', addr ='"+getAddress()+"', email ='"+getEmail()+"', insCo ='"+getInsCo()+"' WHERE patId ='"+getPatId()+"'";
                System.out.println(sql);
                int x = smt.executeUpdate(sql);
                if (x > 0) {
                    System.out.println("Successfully Updated");
                    System.out.println("-----------------------------");
                }
                else
                    System.out.println("ERROR OCCURED :(");
            }
        }//end try//end try
        catch(SQLException e){
            System.out.println(e);
        }     
    }//End updateDB()

    public  static void main(String[] args){
        //SELECT Patient
        Patient p1 = new Patient();
        p1.selectDB("A900");
        p1.display();
    
        //INSERT Patient
        Patient p2 = new Patient();
        p2.insertDB( "A916","4444", "Jinoy", "Sharma", "Atlanta", "js@yahoo.com","Cigna");
        p2.display();
        
        //UPDATE Patient
       // Patient p3 = new Patient();
        //p3.selectDB("A916");
       // p3.setEmail("mail@email.com");
       // p3.updateDB();
        
        //DELETE Patient
        //Patient p4 = new Patient();
        //p4.selectDB("A912");
        //p4.deleteDB();
    }//End main()
}//End class