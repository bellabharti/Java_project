/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.sql.*;
/**
 * @author Bharti Parekh
 */
public class Appointment {
    private String apptDateTime;
    private String patId;
    private String dentId;
    private String procCode;
    private String url = "C:/Users//coned//Downloads/DentistOfficeMDB.mdb";
    
    // Constructor with no argument
    public Appointment(){
    apptDateTime = "";
    patId = "";
    dentId = "";
    procCode= "";
    }
    
    public Appointment(String dateTime,String pid, String did, String pCode) {
    apptDateTime = dateTime;
    patId = pid;
    dentId = did;
    procCode= pCode;
    }
    
    public void selectDB(String pid){
        patId= pid;
        try{
             // Establish a connection
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url)) {
                System.out.println("Database connected");
                // Create a statement
                Statement smt = con.createStatement();
                // Execute a statement
               String sql = "SELECT * FROM Appointments WHERE patId = '"+ pid +"'" ;
                System.out.println(sql);
                ResultSet rs = smt.executeQuery (sql);
                rs.next();
                apptDateTime =rs.getString("apptDateTime");
                patId = rs.getString("patId");
                dentId = rs.getString("dentId");
                procCode = rs.getString("procCode");
            }
        }//end try//end try
        catch(ClassNotFoundException | SQLException e){
            System.out.println(e);
         }
     }//End selectDB()	


    public String getApptDateTime() { return apptDateTime; }
    public void setApptDateTime(String dateTime) { apptDateTime= dateTime ; }
 
    public String getPatID() { return patId; }
    public void setPatID(String pid) { patId= pid ; }

    public String getDentID() { return dentId; }
    public void setDentID(String did) { dentId= did ; }

    public String getProcCode() { return procCode; }
    public void setProcCode(String pCode) {procCode= pCode ; }

    public void display(){
        System.out.println("apptDateTime    = "+ apptDateTime);
        System.out.println("Patient ID      = "+ patId);
        System.out.println("Dentist ID      = "+ dentId);
        System.out.println("ProcCode        = "+ procCode);
        System.out.println("-----------------------------");
    }//End display()
    
    public void insertDB(String dateTime,String pid, String did, String pCode) {
        apptDateTime = dateTime;
        patId = pid;
        dentId = did;
        procCode= pCode;
        // Establish a connection
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url);
            System.out.println("Database connected");
            // Create a statement
            Statement smt;
            smt = con.createStatement();
            // Execute a statement
            String sql = "INSERT into Appointments (apptDateTime, patId, dentId, procCode) VALUES ('"+apptDateTime+"', '"+patId+"', '"+dentId+"', '"+procCode+"')";
            System.out.println(sql);
            int n = smt.executeUpdate(sql);
            if (n == 1) {
               System.out.println("Insert Successful");
            }
            else {
               System.out.println("Insert Failed");
            }
        }//end 
        catch(ClassNotFoundException | SQLException e){
            System.out.println(e);
        }
    }// End insertDB
 
    public void deleteDB() {
        try{
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url) ;
            System.out.println("Database connected");
            // Create a statement
            Statement smt = con.createStatement();
            // Execute a statement
            String sql = "Delete FROM Appointments WHERE patId ='"+patId+"'";
            System.out.println(sql);
            int n = smt.executeUpdate(sql);
            if (n == 1)
                System.out.println("Appointment delete Successfully");
            else
                System.out.println("Delete Failed");
        }//end try//end try                 
        catch(SQLException e){
            System.out.println(e);
        }     
    } //End deleteDB
 
    public void updateDB() {
        try ( //  Establish a connection
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url )) {
            System.out.println("Database connected");
            // Create a statement
            Statement smt = con.createStatement();
            // Updating database
            String sql = "UPDATE  Appointments set apptDateTime ='"+getApptDateTime()+"', dentId ='"+getDentID()+"', procCode ='"+getProcCode()+"' WHERE patId ='"+getPatID()+"'";
            System.out.println(sql);
            int x = smt.executeUpdate(sql);
            if (x > 0) {
                System.out.println("Successfully Updated");
                System.out.println("-----------------------------");
            }
            else
                System.out.println("ERROR OCCURED :(");
            }//end try//end try
        catch(SQLException e){
            System.out.println(e);
        }     
      }//End updateDB()

   public  static void main(String[] args){
       //SELECT Appointment
        Appointment a1;
        a1 = new Appointment();
        a1.selectDB("A908");
        a1.display();
        
        //INSERT Appointment
        Appointment a2 = new Appointment();
        a2.insertDB("May 5", "A908","D201", "P201");
        a2.display();
        
        //UPDATE Appointment
        //Appointment a3 = new Appointment();
        //a3.selectDB("A907");
        //a3.setApptDateTime("May 5th, 9PM");
        //a3.updateDB();
        
        //DELETE Appointment
        //Appointment a4 = new Appointment();
        //a4.selectDB("A");
        //a4.deleteDB();
    }//End main()
}//End class