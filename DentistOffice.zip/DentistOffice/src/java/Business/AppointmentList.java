/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.util.*;
/**
 * @author Bharti Parekh
 */
public class AppointmentList {
   public ArrayList<Appointment> myList = new ArrayList<Appointment>();
   public  int count = 0;

   public void addAppointment(Appointment a1){
       myList.add(a1);
       count++;
   }//end addAppointment()

    public void display(){
        //Call an Appointment Object
        Appointment a1;
        //Display each Appointment in myList
        for(int x=0; x<myList.size(); x++){ 
            a1 = myList.get(x);
            a1.display();
            System.out.println("-----------------------------");
       }
    }//end display()

  public static void main (String[] args){  
    //Initiated A New Appointment And AppointmentList Object
    AppointmentList aList = new AppointmentList();
    Appointment a1;
    
    //Add Appointments To AppointmentList Object
    a1 = new Appointment("May 5, 2018, 3pm", "A900"," D201", "P910");
    aList.addAppointment(a1);
    
    a1 = new Appointment("Jan 15, 2018, 1:30pm", "A901"," D202", "P911");
    aList.addAppointment(a1);
    
    a1 = new Appointment("July 5, 2018, 4pm", "A902"," D203", "P912");
    aList.addAppointment(a1);
    
    a1 = new Appointment("May 9, 2018, 2:15pm", "A903"," D204", "P913");
    aList.addAppointment(a1);
    
    //Display All Appointment in AppointmentList
    aList.display();
    }//end main()
}//end class

    

