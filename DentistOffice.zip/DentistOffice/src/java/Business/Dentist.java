/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;
import java.sql.*;
/**
 * @author coned
 */

public class Dentist { 
    private String id; 
    private String passwd; 
    private String firstName; 
    private String lastName; 
    private String email; 
    private int  office; 
    private String url = "C:/Users//coned//Downloads/DentistOfficeMDB.mdb";
    public AppointmentList aList = new AppointmentList(); 
    /** 
    * This constructor should be called with inputs which already exist in the 
    * Appointments table. 
    */ 

    // Constructor with no argument 
    public Dentist (){ 
        id = ""; 
        passwd = ""; 
        firstName = ""; 
        lastName = ""; 
        email = ""; 
        office = 0; 
    } 

    public Dentist (String iD,String pw, String fname, String lname, String eml, int ofc) { 
        id = iD; 
        passwd = pw; 
        firstName = fname; 
        lastName =  lname; 
        email = eml; 
        office = ofc;   
    } 

    public void selectDB(String iD) throws SQLException{ 
        id= iD; 
        try{// Establish a connection 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url)) { 
                System.out.println("Database connected"); 
                // Create a statement 
                Statement smt = con.createStatement(); 
                // Execute a statement 
                String sql = "SELECT * FROM Dentists WHERE id ='"+iD+"'"; 
                System.out.println(sql); 
                ResultSet rs = smt.executeQuery (sql); 
                rs.next(); 
                id = rs.getString("id"); 
                passwd = rs.getString("passwd"); 
                firstName =  rs.getString("firstName"); 
                lastName =   rs.getString("lastName"); 
                email =  rs.getString("email"); 
                office = rs.getInt("office"); 
                getAppointments();
            } 
        }//end try//end try 
        catch(ClassNotFoundException e){ 
            System.out.println(e); 
        }
     }//end selectDB()     

    public void getAppointments() { 
        try{// Establish a connection 
        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                +url)) { 
                System.out.println("Finding Appointments"); 
                // Create a statement 
                Statement smt = con.createStatement(); 
                // Execute a statement 
                String sql = "SELECT patId FROM Appointments WHERE dentId='"+id+"'"; 
                //System.out.println(sql); 
                ResultSet rs = smt.executeQuery (sql);
                while(rs.next()){ 
                    Appointment a1 = new Appointment();
                    String pid = rs.getNString("patId");
                    a1.selectDB(pid);
                    aList.addAppointment(a1);
                } 
            } 
        }//end try//end try 
        catch(ClassNotFoundException | SQLException e){ 
            System.out.println(e); 
        } 
    }//End getAppointments() 
    
    public String getId() { return id; } 
    public void setId(String iD) { id= iD ; } 

    public String getPassword() { return passwd; } 
    public void setPassword(String pass) {passwd= pass ; } 

    public String getFName() { return firstName; } 
    public void setFName(String fn) {firstName= fn ; } 

    public String getLName() { return lastName; } 
    public void setLName(String ln) {lastName= ln ; } 

    public String getEmail() { return email; }
    public void setEmail(String eml) {email= eml ; } 

    public int getOffice() { return office; } 
    public void setOffice(int off) {office= off ; } 
    
    public void display(){ 
        System.out.println("Dentist ID   = "+ id); 
        System.out.println("Password     = "+ passwd); 
        System.out.println("First Name   = "+ firstName); 
        System.out.println("Last Name    = "+ lastName); 
        System.out.println("Email        = "+ email); 
        System.out.println("Office       = "+ office); 
        System.out.println("");
        System.out.println("***************** My Appointments");
        aList.display();
        System.out.println("*****************");
        System.out.println("-----------------------------");
    }//End display()  

    public void insertDB (String iD,String pw, String fname, String lname, String eml, int ofc) { 
        id = iD; 
        passwd = pw; 
        firstName = fname; 
        lastName =  lname; 
        email = eml; 
        office = ofc; 
        // Establish a connection 
        try { 
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                +url); 
            System.out.println("Database connected"); 
            // Create a statement 
            Statement smt; 
            smt = con.createStatement(); 
            // Execute a statement 
            String sql = "INSERT into Dentists (id, passwd, firstName, lastName, email, office) VALUES ('"+id+"','"+passwd+"','"+firstName+"','"+lastName+"','"+email+"',"+office+")";  
            System.out.println(sql); 
            int n = smt.executeUpdate (sql); 
            if (n == 1) 
                System.out.println("Insert Successful"); 
            else 
                System.out.println("Insert Failed"); 
        }//end  
        catch(ClassNotFoundException | SQLException e){ 
            System.out.println(e); 
        } 
    }// End insertDB 

    public void deleteDB() { 
        try{ 
            Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                +url) ; 
            System.out.println("Database connected"); 
            // Create a statement 
            Statement smt = con.createStatement(); 
            // Execute a statement 
            String sql = "Delete * FROM Dentists WHERE id ='"+id+"'"; 
            System.out.println(sql); 
            int n = smt.executeUpdate (sql); 
            if (n == 1) 
                System.out.println("Dentist deleted Successfully"); 
            else 
                System.out.println("Delete Failed"); 
        }//end try//end try 
        catch(SQLException e){ 
            System.out.println(e); 
        }      
    } //End deleteDB 

    public void updateDB() { 
        try { 
            try ( //  Establish a connection 
                Connection con = DriverManager.getConnection("jdbc:ucanaccess://"
                    +url)) {
                System.out.println("Database connected");
                // Create a statement
                Statement smt = con.createStatement();
                // Updating database
                String sql = "UPDATE Dentists set passwd ='"+getPassword()+"', firstName ='"+getFName()+"', lastName ='"+getLName()+"', email ='"+getEmail()+"', office ='"+getOffice()+"' WHERE id ='"+getId()+"'";
                System.out.println(sql);
                int x = smt.executeUpdate(sql);
                if (x > 0)
                    System.out.println("Successfully Updated");
                else
                    System.out.println("ERROR OCCURED :(");
            }
        }//end try //end try 
        catch(SQLException e){ 
            System.out.println(e); 
        }      
    } 

   public  static void main(String[] args) throws SQLException{ 
        //SELECT Dentist
        Dentist d1 = new Dentist(); 
        d1.selectDB("D202"); 
        d1.getAppointments();
        d1.display(); 
        
        //INSERT Dentist
        Dentist d2 = new Dentist (); 
        d2.insertDB("D207","4444","Komal","Shah","ks@yahoo.com",542); 
        d2.display(); 
        
        //UPDATE Dentist
        Dentist d3 = new Dentist();
        d3.selectDB("D207");
        d3.setFName("Bella");
        d3.updateDB();
        
        //DELETE Dentist
        //Dentist d4 = new Dentist(); 
        //d4.selectDB("D207"); 
        //d4.deleteDB();
    }//End main()
}//End class